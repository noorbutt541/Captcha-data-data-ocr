# Payment-Card-OCR
Automatic details extraction from Payment cards with OCR and OpenCV

This project is developed in Python.

The main theme of my project is not to waste time in filling forms in online payment activities.

So, just by uploading front side picture of any payment card like credit card or debit card, the details which are asked by payment forms are retrieved and displayed in their respective controls.

table_db_create.py is the file that creates database and the table of card owners.

insert_into_table.py is the dummy code to fill the table with card owners. (You have to replace this file with bank's file to use this project in real time)

payment_ocr.py has the main code that performs optical character recognition which recognizes card number that undergoes comparision with database to retrieve the details of the owner.

printing_records.py is for me(developer) to check what are the record in the table.

number_retrieve.py just display card number on kernal.

by - 

Username :- #srikarsharan097

Kanneganti Srikar Sharan

Student of Bapatla Engineering College (2015-2019)

Email :- srikarsharan097@gmail.com (Any queries? Contact me..)
